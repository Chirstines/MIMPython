"""  
https://github.com/Chirstines/MIMPython_Week05

- Viết commit 
- Tạo ra một Tag tên Beta mới đánh dấu vào commit cuối
- Tạo issue 'Những điều cần biết về GitHub' (https://github.com/Chirstines/MIMPython_Week05/issues/1)
- Viết README
"""
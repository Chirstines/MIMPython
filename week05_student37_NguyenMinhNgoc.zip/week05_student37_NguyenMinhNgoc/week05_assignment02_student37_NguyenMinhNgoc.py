""" Assignment02_NguyenMinhNgoc.md
"""